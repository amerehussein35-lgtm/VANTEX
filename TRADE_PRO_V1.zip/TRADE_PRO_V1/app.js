const signals=[
 {asset:"XAUUSD",name:"Gold",type:"BUY",entry:"2,365.45",sl:"2,320.00",tp1:"2,380.00",tp2:"2,415.00",tp3:"2,450.00",risk:"1%",status:"مفتوحة",cat:"gold",icon:"Au"},
 {asset:"EURUSD",name:"Euro / Dollar",type:"SELL",entry:"1.08245",sl:"1.09000",tp1:"1.07800",tp2:"1.07300",tp3:"1.06800",risk:"1%",status:"مفتوحة",cat:"forex",icon:"€"},
 {asset:"US100",name:"Nasdaq",type:"BUY",entry:"18,765.50",sl:"18,500.00",tp1:"18,900.00",tp2:"19,200.00",tp3:"19,500.00",risk:"1.5%",status:"مفتوحة",cat:"indices",icon:"N"},
 {asset:"BTCUSD",name:"Bitcoin",type:"SELL",entry:"67,245.30",sl:"68,900.00",tp1:"66,800.00",tp2:"65,500.00",tp3:"64,000.00",risk:"1%",status:"مفتوحة",cat:"crypto",icon:"₿"},
 {asset:"GBPUSD",name:"Pound / Dollar",type:"BUY",entry:"1.27680",sl:"1.26800",tp1:"1.28200",tp2:"1.28800",tp3:"1.29500",risk:"1%",status:"TP1",cat:"forex",icon:"£"},
 {asset:"XAUUSD",name:"Gold",type:"SELL",entry:"2,410.00",sl:"2,430.00",tp1:"2,395.00",tp2:"2,380.00",tp3:"2,360.00",risk:"0.5%",status:"TP3",cat:"gold",icon:"Au"}
];
const courses=[
 ["أساسيات التداول","من الصفر إلى الاحتراف","↗",43],
 ["التحليل الفني","المستوى المتقدم","⌁",70],
 ["Smart Money Concepts","منهج المؤسسات","◈",65],
 ["Price Action","احتراف حركة السعر","⌁",55],
 ["إدارة رأس المال","حماية وتنمية رأس المال","♙",80],
 ["الاستراتيجية الخاصة","استراتيجية القناة المتقدمة","♛",45]
];
const trades=[
 ["2026-08-26","XAUUSD","BUY","2,365.45","2,415.00","TP2","+495$"],
 ["2026-08-25","EURUSD","SELL","1.08245","1.07800","TP1","+445$"],
 ["2026-08-24","US100","BUY","18,765.50","18,900.00","TP1","+134$"],
 ["2026-08-23","BTCUSD","SELL","67,245.30","68,900.00","SL","-165$"],
 ["2026-08-22","GBPUSD","BUY","1.27680","1.28800","TP2","+112$"],
 ["2026-08-21","XAUUSD","SELL","2,410.00","2,360.00","TP3","+500$"]
];

function signalHTML(s){
 const cls=s.type==="BUY"?"buy-txt":"sell-txt";
 return `<div class="signal-item"><div class="coin">${s.icon}</div><div><strong>${s.asset}</strong><small>${s.name} · ${s.status}</small></div><div class="side-price"><b class="${cls}">${s.type}</b><small>${s.entry}</small></div></div>`;
}
function render(){
 document.getElementById("latestSignals").innerHTML=signals.slice(0,4).map(signalHTML).join("");
 document.getElementById("signalTable").innerHTML=signals.slice(0,4).map(s=>`<tr><td><b>${s.asset}</b></td><td class="${s.type==="BUY"?"buy-txt":"sell-txt"}">${s.type}</td><td>${s.entry}</td><td>${s.sl}</td><td>${s.tp1}</td><td><span class="status">${s.status}</span></td></tr>`).join("");
 document.getElementById("allSignals").innerHTML=signals.map(s=>`<tr data-cat="${s.cat}"><td><b>${s.asset}</b></td><td class="${s.type==="BUY"?"buy-txt":"sell-txt"}">${s.type}</td><td>${s.entry}</td><td>${s.sl}</td><td>${s.tp1}</td><td>${s.tp2}</td><td>${s.tp3}</td><td>${s.risk}</td><td><span class="status">${s.status}</span></td></tr>`).join("");
 document.getElementById("featuredCourses").innerHTML=courses.slice(0,6).map(c=>`<div class="course-mini"><div class="course-cover">${c[2]}</div><p>${c[0]}</p><div class="progress"><span style="width:${c[3]}%"></span></div></div>`).join("");
 document.getElementById("courseGrid").innerHTML=courses.map(c=>`<div class="course-card card"><div class="cover">${c[2]}</div><div class="body"><h3>${c[0]}</h3><p>${c[1]} — دروس عملية وتمارين وتطبيقات على السوق.</p><div class="course-meta"><span>${c[3]}% مكتمل</span><span>12 درس</span></div><div class="progress"><span style="width:${c[3]}%"></span></div><button class="outline-btn full" onclick="toast('سيتم فتح محتوى ${c[0]} بعد تسجيل الدخول')">فتح الكورس</button></div></div>`).join("");
 document.getElementById("tradeLog").innerHTML=trades.map(t=>`<tr><td>${t[0]}</td><td>${t[1]}</td><td class="${t[2]==="BUY"?"buy-txt":"sell-txt"}">${t[2]}</td><td>${t[3]}</td><td>${t[4]}</td><td><span class="status">${t[5]}</span></td><td class="${t[6][0]==="+"?"buy-txt":"sell-txt"}">${t[6]}</td></tr>`).join("");
}
function showSection(id){
 document.querySelectorAll(".section").forEach(s=>s.classList.toggle("active",s.id===id));
 document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.section===id));
 window.scrollTo({top:0,behavior:"smooth"});
 document.getElementById("sidebar").classList.remove("open");
}
document.querySelectorAll(".nav-item").forEach(b=>b.addEventListener("click",()=>showSection(b.dataset.section)));
function toggleSidebar(){document.getElementById("sidebar").classList.toggle("open")}
function toast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>t.classList.remove("show"),2600)}
function setFilter(btn,cat){
 document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));btn.classList.add("active");
 document.querySelectorAll("#allSignals tr").forEach(row=>row.style.display=(cat==="all"||row.dataset.cat===cat)?"":"none");
}
function filterContent(q){
 q=q.trim().toLowerCase();
 document.querySelectorAll(".signal-item,.course-card,tbody tr").forEach(el=>{el.style.display=(!q||el.textContent.toLowerCase().includes(q))?"":"none"});
}
render();